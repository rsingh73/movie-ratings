import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MovieratingServiceService } from '../movierating-service.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.scss'],
})
export class MovieComponent implements OnInit {
  registerForm: FormGroup;
  movies = [];
  movieDetails = [];
  sortrder = "lowTohigh"

  // ---------------------
  view: any = [700, 400];
  colorScheme = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
  };
  single = [];

  showXAxis: boolean = true;
  showYAxis: boolean = true;
  gradient: boolean = false;
  showLegend: boolean = true;
  showXAxisLabel: boolean = true;
  yAxisLabel: string = 'Rating';
  showYAxisLabel: boolean = true;
  xAxisLabel: string = 'Movie';

  // ---------------------
  constructor(
    private formBuilder: FormBuilder,
    private ratingService: MovieratingServiceService
  ) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name: [''],
    });
  }

  get f() {
    return this.registerForm.controls;
  }

  onSearch() {
    const title = this.f.name.value;
    console.log(this.f.name.value);
    if (this.registerForm.invalid) {
      return;
    }
    this.ratingService.searchMoviesByTitle(title).subscribe((response: any) => {
      console.log(response.Search);
      this.movies = response.Search;
    });
  }

  selectedMovie(id: string) {
    this.movies = [];
    console.log(id);
    this.ratingService.getMovieDetails(id).subscribe((response: any) => {
      console.log(response);
      this.single.push({
        "name": response.Title,
        "value": parseFloat(response.Ratings[0].Value)
      })
      this.single = [...this.single]
      this.movieDetails.push(response);
    });
  }

  sortByRating(order) {
    if (order === "lowTohigh") {
    this.single.sort((a, b) => (a.value > b.value) ? 1 : -1)
    this.sortrder = "highTolow"
    } else {
      this.single.sort((a, b) => (a.value < b.value) ? 1 : -1)
    this.sortrder = "lowTohigh"
    }
    this.single = [...this.single]
    console.log(this.single)
  }
}

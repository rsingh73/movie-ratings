import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MovieratingServiceService {
  constructor(private http: HttpClient) {}

  searchMoviesByTitle(title: string) {
    let searchParams = new HttpParams();
    searchParams = searchParams.append('s', title);
    searchParams = searchParams.append('page', '1');
    // let headers =
    return this.http.get(
      'https://movie-database-imdb-alternative.p.rapidapi.com/',
      {
        headers: new HttpHeaders({
          'x-rapidapi-key':
            '6cf4974ffemshdd6f5ffdec9da6ep175cf8jsnb3d2bc705926',
          'x-rapidapi-host': 'movie-database-imdb-alternative.p.rapidapi.com',
        }),
        params: searchParams,
        responseType: 'json',
      }
    );
  }

  getMovieDetails(id: string) {
    let searchParams = new HttpParams();
    searchParams = searchParams.append('i', id);
    // searchParams = searchParams.append('page', '1');
    return this.http.get(
      'https://movie-database-imdb-alternative.p.rapidapi.com/',
      {
        headers: new HttpHeaders({
          'x-rapidapi-key':
            '6cf4974ffemshdd6f5ffdec9da6ep175cf8jsnb3d2bc705926',
          'x-rapidapi-host': 'movie-database-imdb-alternative.p.rapidapi.com',
        }),
        params: searchParams,
        responseType: 'json',
      }
    );
  }
}

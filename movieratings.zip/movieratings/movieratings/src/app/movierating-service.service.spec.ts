import { TestBed } from '@angular/core/testing';

import { MovieratingServiceService } from './movierating-service.service';

describe('MovieratingServiceService', () => {
  let service: MovieratingServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MovieratingServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

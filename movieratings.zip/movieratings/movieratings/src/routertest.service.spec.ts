import { TestBed } from '@angular/core/testing';

import { RoutertestService } from './routertest.service';

describe('RoutertestService', () => {
  let service: RoutertestService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RoutertestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
